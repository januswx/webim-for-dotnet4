﻿using System;
using System.Collections.Generic;

namespace Webim
{
    //TODO: Should be in DB.
    public static class WebimConfig
    {
        public static string VERSION = "1.0";
        public static string DOMAIN = "dotnet.webim20.cn";
        public static string APIKEY = "460cf5d46be2c04e";
        public static string HOST = "webim20.cn";
        public static int PORT = 8888;
    }

}
