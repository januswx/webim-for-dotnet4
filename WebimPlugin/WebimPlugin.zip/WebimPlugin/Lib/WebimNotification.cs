﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Spacebuilder.Webim
{
    public class WebimNotification
    {
        public WebimNotification(){}
    }
}
