﻿namespace Spacebuilder.Webim
{

    public class WebimMenu
    {

        public WebimMenu()
        { 
        
        }
    }

}
