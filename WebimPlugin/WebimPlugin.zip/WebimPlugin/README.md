webim-plugin-spacebuilder
=========================

webim plugin for space builder
